a=4
b=6
res=a*b
